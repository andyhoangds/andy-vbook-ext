load('config.js');
function execute() {
    let response = httpGet(BASE_URL + "/the-loai");
    if (response.ok) {
        let doc = response.html();
        let genres = [];
        let seen = {};
        doc.select("a[href*='/the-loai/']").forEach(function (e) {
            let href = e.attr("href");
            if (!href) return;
            let link = absUrl(href).split("?")[0];
            if (seen[link]) return;
            seen[link] = true;
            let title = e.text();
            if (!title) return;
            genres.push({
                title: title,
                input: link,
                script: "gen.js"
            });
        });
        if (genres.length > 0) {
            return Response.success(genres);
        }
    }
    return Response.success([
        { title: "Full màu", input: BASE_URL + "/the-loai/full-color", script: "gen.js" },
        { title: "Không che", input: BASE_URL + "/the-loai/khong-che", script: "gen.js" }
    ]);
}
