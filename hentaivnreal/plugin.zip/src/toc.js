load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://hentaivnreal.com/truyen/ojisan-meat-shop");
    let response = httpGet(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let data = [];
    let seen = {};
    doc.select("h2.chuong_t").forEach(function (h) {
        let a = h.parent();
        if (!a) return;
        let href = a.attr("href");
        if (!href) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        data.push({
            name: h.text(),
            url: link,
            host: BASE_URL
        });
    });
    if (data.length === 0) {
        return Response.error("Không lấy được danh sách chương");
    }
    let out = [];
    for (let i = data.length - 1; i >= 0; i--) {
        out.push(data[i]);
    }
    return Response.success(out);
}
