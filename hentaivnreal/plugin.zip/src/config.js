let BASE_URL = "https://hentaivnreal.com";
try {
    if (CONFIG_URL) {
        let origin = String(CONFIG_URL).match(/^(https?:\/\/[^\/]+)/);
        if (origin) {
            BASE_URL = origin[1];
        }
    }
} catch (error) {
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function normalizeIncomingUrl(url) {
    if (!url) return "";
    url = String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (/\/truyen\/[^\/]+\/$/.test(url)) {
        url = url.replace(/\/$/, "");
    }
    return url;
}

function bgUrl(style) {
    if (!style) return "";
    let m = String(style).match(/url\((['\"]?)([^)'\"]+)\1\)/);
    return m ? m[2] : "";
}

function httpGet(url) {
    let until = new Date().getTime() + 365 * 24 * 3600 * 1000;
    return fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml",
            "Cookie": "hvnr_vn_verify=" + until
        }
    });
}

function parseBookList(doc) {
    let data = [];
    let seen = {};
    doc.select("ul.page-item li.item").forEach(function (e) {
        let a = e.select("a[href*='/truyen/']").first();
        if (!a) return;
        let href = a.attr("href");
        if (!href) return;
        if (href.indexOf("/chap-") >= 0 || href.indexOf("/phan-") >= 0) return;
        let link = absUrl(href).replace(/\/$/, "");
        if (seen[link]) return;
        seen[link] = true;
        let thumb = e.select(".thumb-box").first();
        let img = e.select("img").first();
        let cover = "";
        if (thumb) cover = bgUrl(thumb.attr("style"));
        if (!cover && img) cover = img.attr("src");
        let chap = e.select(".info-detail_2, .info-detail").first();
        data.push({
            name: e.select(".film-name").text() || a.attr("title") || a.text(),
            link: link,
            cover: absUrl(cover),
            description: chap ? chap.text() : "",
            host: BASE_URL
        });
    });
    return data;
}

function nextPageUrl(listUrl, doc) {
    let m = String(listUrl || "").match(/[?&]page=(\d+)/);
    let page = m ? parseInt(m[1], 10) : 1;
    let next = page + 1;
    let probe = doc.select('a[href*="page=' + next + '"]');
    if (probe.size() === 0) return "";
    return absUrl(probe.first().attr("href"));
}
