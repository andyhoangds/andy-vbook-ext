load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL chương. Dán ví dụ: https://hentaivnreal.com/truyen/ojisan-meat-shop/chap-1");
    let response = httpGet(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let data = [];
    doc.select("img[src*='/manga-images/']").forEach(function (e) {
        let img = e.attr("src");
        if (!img) return;
        data.push({
            link: absUrl(img),
            fallback: []
        });
    });
    if (data.length === 0) {
        return Response.error("Không lấy được ảnh chương");
    }
    return Response.success(data);
}
