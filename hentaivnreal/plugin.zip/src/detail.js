load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://hentaivnreal.com/truyen/ojisan-meat-shop");
    let response = httpGet(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let nameEl = doc.select("h1").first();
    let coverEl = doc.select("img[src*='cdn.hentaivnreal.com']").first();
    let authorEl = doc.select("a[href*='/tac-gia/']").first();
    if (!authorEl) authorEl = doc.select("a[href*='/author/']").first();

    let genres = [];
    doc.select("a.tag[href*='/the-loai/']").forEach(function (e) {
        genres.push({
            title: e.text(),
            input: absUrl(e.attr("href")),
            script: "gen.js"
        });
    });

    return Response.success({
        name: nameEl ? nameEl.text() : "",
        cover: coverEl ? absUrl(coverEl.attr("src")) : "",
        author: authorEl ? authorEl.text() : "",
        description: "",
        detail: "",
        ongoing: true,
        genres: genres,
        host: BASE_URL
    });
}
