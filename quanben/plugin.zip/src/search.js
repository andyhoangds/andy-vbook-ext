load('config.js');

function searchToken(keywords) {
    let staticchars = "PAhw7UT1B0a9kQDKZsjIASmOezxYG4CHo5Jyfg2b8FLpEvRr3WtVnlqMidu6oN";
    let encoded = encodeURI(keywords);
    let encodechars = "";
    for (let i = 0; i < encoded.length; i++) {
        let ch = encoded.charAt(i);
        let num0 = staticchars.indexOf(ch);
        let code = num0 === -1 ? ch : staticchars.charAt((num0 + 3) % 62);
        let num1 = Math.floor(Math.random() * 62);
        let num2 = Math.floor(Math.random() * 62);
        encodechars += staticchars.charAt(num1) + code + staticchars.charAt(num2);
    }
    return encodeURI(encodechars);
}

function execute(key, page) {
    let keywords = String(key || "").replace(/^\s+|\s+$/g, "");
    if (!keywords) return Response.error("Nhập từ khóa tìm kiếm");
    let t = new Date().getTime();
    let url = BASE_URL + "/?c=book&a=search.json&callback=search&t=" + t
        + "&keywords=" + encodeURIComponent(keywords)
        + "&b=" + searchToken(keywords);
    let referer = BASE_URL + "/?c=book&a=search&keyword=" + encodeURIComponent(keywords);
    let response = fetch(url, {
        headers: {
            "Referer": referer,
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
        }
    });
    if (!response.ok) return Response.error("HTTP " + response.status);
    let text = response.text() || "";
    let html = "";
    let m = text.match(/search\(([\s\S]*)\)\s*;?\s*$/);
    if (m) {
        try {
            let obj = JSON.parse(m[1]);
            html = obj.content || "";
        } catch (e) {
            html = "";
        }
    }
    if (!html) return Response.success([]);
    let doc = Html.parse(html);
    let data = parseBookList(doc);
    return Response.success(data);
}
