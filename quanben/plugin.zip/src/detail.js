load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://quanben-xiaoshuo.com/n/ananliaore/");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let coverEl = doc.select(".pic img").first();
    let coverImg = coverEl ? coverEl.attr("src") : "";

    let authorEl = doc.select("span[itemprop=author]").first();
    let introEl = doc.select(".articlebody").first();
    let intro = introEl ? introEl.html() : "";

    let genres = [];
    let crumbs = doc.select(".breadcrumb a");
    if (crumbs.size() > 1) {
        let catEl = crumbs.get(1);
        genres.push({
            title: catEl.text(),
            input: absUrl(catEl.attr("href")),
            script: "gen.js"
        });
    }

    let infoHtml = doc.select(".info").html() || "";

    return Response.success({
        name: doc.select("h1.h1, h1[itemprop=name]").first() ? doc.select("h1.h1, h1[itemprop=name]").first().text() : "",
        cover: coverImg,
        author: authorEl ? authorEl.text() : "",
        description: intro,
        detail: infoHtml,
        ongoing: false,
        genres: genres,
        host: BASE_URL
    });
}
