load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL chương. Dán ví dụ: https://quanben-xiaoshuo.com/n/ananliaore/1.html");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let content = doc.select("#articlebody, .articlebody");
    if (content.isEmpty()) {
        return Response.error("Không lấy được nội dung chương");
    }
    let html = content.html() || "";
    html = html.replace(/<script[\s\S]*?<\/script>/gi, "");
    html = html.replace(/<span id="ad"><\/span>/gi, "");
    html = html.replace(/<!--PAGE \d+-->/g, "");
    return Response.success(html);
}
