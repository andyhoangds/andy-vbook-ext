load('config.js');
function execute() {
    let response = fetch(BASE_URL + "/");
    if (response.ok) {
        let doc = response.html();
        let genres = [];
        let seen = {};
        doc.select("dd ul.list a[itemprop=url]").forEach(function (e) {
            let href = e.attr("href");
            if (!href || href.indexOf("/category/") < 0) return;
            let link = absUrl(href);
            if (seen[link]) return;
            seen[link] = true;
            genres.push({
                title: e.text(),
                input: link,
                script: "gen.js"
            });
        });
        if (genres.length > 0) {
            return Response.success(genres);
        }
    }
    return Response.success([
        { title: "玄幻小说", input: BASE_URL + "/category/xuanhuanxiaoshuo.html", script: "gen.js" },
        { title: "都市小说", input: BASE_URL + "/category/dushixiaoshuo.html", script: "gen.js" },
        { title: "言情小说", input: BASE_URL + "/category/yanqingxiaoshuo.html", script: "gen.js" }
    ]);
}
