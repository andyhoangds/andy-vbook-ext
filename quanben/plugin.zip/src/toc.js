load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://quanben-xiaoshuo.com/n/ananliaore/");
    let slug = bookSlug(url);
    if (!slug) return Response.error("Không đọc được slug truyện");
    let tocUrl = BASE_URL + "/n/" + slug + "/xiaoshuo.html";
    let response = fetch(tocUrl);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let data = [];
    doc.select("ul.list a[itemprop=url], ul.list a").forEach(function (e) {
        let href = e.attr("href");
        if (!href || href.indexOf(".html") < 0) return;
        if (href.indexOf("xiaoshuo") >= 0) return;
        data.push({
            name: e.text(),
            url: absUrl(href),
            host: BASE_URL
        });
    });
    return Response.success(data);
}
