load('config.js');
function execute() {
    return Response.success([
        { title: "最新更新", input: BASE_URL + "/", script: "gen.js" },
        { title: "玄幻小说", input: BASE_URL + "/category/xuanhuanxiaoshuo.html", script: "gen.js" },
        { title: "都市小说", input: BASE_URL + "/category/dushixiaoshuo.html", script: "gen.js" },
        { title: "言情小说", input: BASE_URL + "/category/yanqingxiaoshuo.html", script: "gen.js" }
    ]);
}
