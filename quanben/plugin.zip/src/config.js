let BASE_URL = "https://quanben-xiaoshuo.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function normalizeIncomingUrl(url) {
    if (!url) return "";
    url = String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (/\/n\/[^\/]+$/.test(url) && url.indexOf(".html") < 0) {
        url = url + "/";
    }
    return url;
}

function bookSlug(url) {
    let m = String(url).match(/\/n\/([^\/]+)/);
    return m ? m[1] : "";
}

function parseBookList(doc) {
    let data = [];
    let seen = {};
    let homeItems = doc.select("ul.text_list li");
    if (homeItems.size() > 0) {
        homeItems.forEach(function (e) {
            let a = e.select("a.title").first();
            if (!a) a = e.select("a[itemprop=url]").first();
            if (!a) return;
            let href = a.attr("href");
            if (!href || href.indexOf("/n/") < 0) return;
            let link = absUrl(href);
            if (seen[link]) return;
            seen[link] = true;
            let author = e.select("span[itemprop=author]").first();
            data.push({
                name: a.text(),
                link: link,
                cover: "",
                description: author ? author.text() : "",
                host: BASE_URL
            });
        });
        if (data.length > 0) return data;
    }
    doc.select("ul.list2 li a[itemprop=url], .book h1 a").forEach(function (a) {
        let href = a.attr("href");
        if (!href || href.indexOf("/n/") < 0) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        data.push({
            name: a.text(),
            link: link,
            cover: "",
            description: "",
            host: BASE_URL
        });
    });
    return data;
}

function nextPageUrl(doc) {
    let cur = doc.select("ul.list.c a.current").first();
    if (!cur) return "";
    let href = String(cur.attr("href") || "");
    let m = href.match(/(\/category\/[a-z0-9]+)(?:-(\d+))?\.html$/i);
    if (!m) return "";
    let stem = m[1];
    let page = m[2] ? parseInt(m[2], 10) : 1;
    let nextHref = stem + "-" + (page + 1) + ".html";
    let probe = doc.select('ul.list.c a[href="' + nextHref + '"]');
    if (probe.size() === 0) return "";
    return absUrl(nextHref);
}
