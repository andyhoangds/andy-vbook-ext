let BASE_URL = "https://quanben-xiaoshuo.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function normalizeIncomingUrl(url) {
    if (!url) return "";
    url = String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (/\/n\/[^\/]+$/.test(url) && url.indexOf(".html") < 0) {
        url = url + "/";
    }
    return url;
}

function bookSlug(url) {
    let m = String(url).match(/\/n\/([^\/]+)/);
    return m ? m[1] : "";
}

function parseBookList(doc) {
    let data = [];
    let seen = {};
    let homeItems = doc.select("ul.text_list li");
    if (homeItems.size() > 0) {
        homeItems.forEach(function (e) {
            let a = e.select("a.title").first();
            if (!a) a = e.select("a[itemprop=url]").first();
            if (!a) return;
            let href = a.attr("href");
            if (!href || href.indexOf("/n/") < 0) return;
            let link = absUrl(href);
            if (seen[link]) return;
            seen[link] = true;
            let author = e.select("span[itemprop=author]").first();
            data.push({
                name: a.text(),
                link: link,
                cover: "",
                description: author ? author.text() : "",
                host: BASE_URL
            });
        });
        if (data.length > 0) return data;
    }
    doc.select("ul.list2 li a[itemprop=url], .book h1 a").forEach(function (a) {
        let href = a.attr("href");
        if (!href || href.indexOf("/n/") < 0) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        data.push({
            name: a.text(),
            link: link,
            cover: "",
            description: "",
            host: BASE_URL
        });
    });
    return data;
}

function nextPageUrl(doc) {
    let blocks = doc.select("ul.list.c");
    if (blocks.size() === 0) return "";
    let block = blocks.size() > 1 ? blocks.get(1) : blocks.first();
    let as = block.select("a");
    let found = false;
    let next = "";
    as.forEach(function (e) {
        if (found && !next) {
            next = absUrl(e.attr("href"));
        }
        if (e.hasClass("current")) {
            found = true;
        }
    });
    return next;
}
