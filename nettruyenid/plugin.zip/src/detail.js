load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://nettruyen.gg/truyen-tranh/anh-hung-giai-cap-tu-san");
    let r = fetchDoc(url);
    if (!r.ok) return Response.error("HTTP " + r.status);
    let doc = r.doc;

    let nameEl = doc.select("h1.title-detail").first();
    if (!nameEl) nameEl = doc.select("h1").first();

    let coverEl = doc.select(".detail-info img").first();
    if (!coverEl) coverEl = doc.select("img.image-thumb").first();
    let cover = pickCoverFromImg(coverEl);

    let authors = [];
    let authorEls = doc.select("a[href*='/tac-gia/']");
    for (let i = 0; i < authorEls.size(); i++) {
        let t = authorEls.get(i).text();
        if (t) authors.push(t);
    }
    if (authors.length === 0) {
        let authorText = doc.select("li.author .col-xs-8").first();
        if (authorText) {
            let t = String(authorText.text()).replace(/^\s+|\s+$/g, "");
            if (t) authors.push(t);
        }
    }

    let statusEl = doc.select("li.status .col-xs-8").first();
    let status = statusEl ? statusEl.text() : "";
    let ongoing = status.indexOf("Đang") >= 0 || status.indexOf("dang") >= 0 || status.indexOf("Dang") >= 0;

    let descEl = doc.select(".detail-content p").first();

    let genres = [];
    let seen = {};
    let genreEls = doc.select("li.kind a[href*='/tim-truyen/']");
    if (genreEls.size() === 0) genreEls = doc.select("li.kind a[href*='/the-loai/']");
    for (let i = 0; i < genreEls.size(); i++) {
        let e = genreEls.get(i);
        let href = e.attr("href");
        if (!href) continue;
        let link = absUrl(href).split("?")[0].replace(/\/$/, "");
        if (seen[link]) continue;
        seen[link] = true;
        genres.push({
            title: e.text(),
            input: link,
            script: "gen.js"
        });
    }

    return Response.success({
        name: nameEl ? nameEl.text() : "",
        cover: absUrl(cover),
        author: authors.join(", "),
        description: descEl ? descEl.text() : "",
        detail: status,
        ongoing: ongoing,
        genres: genres,
        host: BASE_URL
    });
}
