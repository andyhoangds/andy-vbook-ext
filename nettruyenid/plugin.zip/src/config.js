let BASE_URL = "https://nettruyen.gg";
try {
    if (CONFIG_URL) {
        let origin = String(CONFIG_URL).match(/^(https?:\/\/[^\/]+)/);
        if (origin) {
            BASE_URL = origin[1];
        }
    }
} catch (error) {
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function normalizeIncomingUrl(url) {
    if (!url) return "";
    url = String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (/\/truyen-tranh\/[^\/]+\/$/.test(url)) {
        url = url.replace(/\/$/, "");
    }
    return url;
}

function isComicDetailHref(href) {
    if (!href) return false;
    let path = String(href).split("?")[0].replace(/\/$/, "");
    if (/\/(chuong|chapter)[-_]/.test(path)) return false;
    return /\/truyen-tranh\/[^\/]+$/.test(path);
}

function isPlaceholderCover(url) {
    if (!url) return true;
    url = String(url).toLowerCase();
    if (url.indexOf("data:") === 0) return true;
    if (url.indexOf("thumb-default") >= 0) return true;
    if (url.indexOf("logo") >= 0) return true;
    if (url.indexOf("1x1") >= 0) return true;
    return false;
}

function pickCoverFromImg(img) {
    if (!img) return "";
    let candidates = [
        img.attr("data-original"),
        img.attr("data-retries"),
        img.attr("data-src"),
        img.attr("data-lazy-src"),
        img.attr("src")
    ];
    for (let i = 0; i < candidates.length; i++) {
        let c = candidates[i];
        if (!c) continue;
        c = String(c).replace(/^\s+|\s+$/g, "");
        if (!c || isPlaceholderCover(c)) continue;
        return absUrl(c);
    }
    return "";
}

function withPage(url, page) {
    url = String(url);
    if (/[?&]page=\d+/.test(url)) {
        return url.replace(/([?&]page=)\d+/, "$1" + page);
    }
    if (url.indexOf("?") >= 0) return url + "&page=" + page;
    return url + "?page=" + page;
}

function httpGet(url) {
    return fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/json",
            "Accept-Language": "vi,en;q=0.9",
            "Referer": BASE_URL + "/",
            "X-Requested-With": "XMLHttpRequest"
        }
    });
}

function comicSlugFromUrl(url) {
    let m = String(url || "").match(/\/truyen-tranh\/([^\/?#]+)/);
    return m ? m[1] : "";
}

function chapterUrlFromItem(slug, item) {
    if (!slug || !item) return "";
    let num = item.chapter_num;
    if (num === undefined || num === null || num === "") {
        let slugChap = item.chapter_slug || "";
        let m = String(slugChap).match(/(?:chuong|chapter)[-_]?([0-9.]+)/i);
        if (m) num = m[1];
    }
    if (num === undefined || num === null || num === "") return "";
    return BASE_URL + "/truyen-tranh/" + slug + "/chuong-" + num;
}

function fetchChapterListApi(slug) {
    if (!slug) return null;
    let api = BASE_URL + "/Comic/Services/ComicService.asmx/ChapterList?slug=" + encodeURIComponent(slug);
    let response = httpGet(api);
    if (!response || !response.ok) return null;
    let data = null;
    try {
        data = response.json();
    } catch (e) {
        try {
            data = JSON.parse(response.text());
        } catch (e2) {
            data = null;
        }
    }
    if (!data) return null;
    let list = data.data || data;
    if (!list || !list.length) return null;
    return list;
}

function unwrapTemplates(html) {
    html = String(html || "");
    html = html.replace(/<template\b/gi, "<div");
    html = html.replace(/<\/template>/gi, "</div>");
    return html;
}

function fetchDoc(url) {
    let response = httpGet(url);
    if (!response || !response.ok) {
        return {
            ok: false,
            status: response ? response.status : 0,
            doc: null,
            html: ""
        };
    }
    let html = "";
    try {
        html = response.text() || "";
    } catch (e) {
        html = "";
    }
    html = unwrapTemplates(html);
    return {
        ok: true,
        status: 200,
        doc: Html.parse(html),
        html: html
    };
}

function nextPageUrl(listUrl, doc) {
    let m = String(listUrl || "").match(/[?&]page=(\d+)/);
    let page = m ? parseInt(m[1], 10) : 1;
    let next = page + 1;
    let found = false;
    let links = doc.select("ul.pagination a.page-link");
    for (let i = 0; i < links.size(); i++) {
        let t = String(links.get(i).text()).replace(/^\s+|\s+$/g, "");
        if (t === String(next)) found = true;
    }
    if (!found) return "";
    return withPage(listUrl, next);
}

function parseBookList(doc) {
    let data = [];
    let seen = {};
    let els = doc.select(".items .item");
    if (els.size() === 0) els = doc.select("div.item");
    for (let i = 0; i < els.size(); i++) {
        let e = els.get(i);
        let a = e.select("h3 a[href*='/truyen-tranh/']").first();
        if (!a) a = e.select("a[href*='/truyen-tranh/']").first();
        if (!a) continue;
        let href = a.attr("href");
        if (!isComicDetailHref(href)) continue;
        let link = absUrl(href).replace(/\/$/, "");
        if (seen[link]) continue;
        seen[link] = true;
        let img = e.select("img.image-thumb").first();
        if (!img) img = e.select("img.lazy").first();
        if (!img) img = e.select("img").first();
        let cover = pickCoverFromImg(img);
        let name = a.attr("title") || a.text();
        let chap = e.select("li.chapter a").first();
        if (!chap) chap = e.select("a[href*='/chuong-']").first();
        data.push({
            name: name,
            link: link,
            cover: cover,
            description: chap ? chap.text() : "",
            host: BASE_URL
        });
    }
    return data;
}

function parseBookListRegex(html) {
    let data = [];
    let seen = {};
    let re = /<a[^>]*title="([^"]+)"[^>]*href="([^"]*\/truyen-tranh\/[^"]+)"[^>]*>/gi;
    let m;
    while ((m = re.exec(html)) !== null) {
        let href = m[2];
        if (!isComicDetailHref(href)) continue;
        let link = absUrl(href).replace(/\/$/, "");
        if (seen[link]) continue;
        seen[link] = true;
        data.push({
            name: m[1],
            link: link,
            cover: "",
            description: "",
            host: BASE_URL
        });
    }
    return data;
}
