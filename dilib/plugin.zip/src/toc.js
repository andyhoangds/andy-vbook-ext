load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://dilib.vn/dao-hai-tac-one-piece-14728.html");
    let response = httpGet(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let items = [];
    let seen = {};
    doc.select("div.col-md-3 a[href*='-chap-']").forEach(function (a) {
        let href = a.attr("href");
        if (!href) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        let name = a.text();
        if (!name) {
            let m = href.match(/chap-([0-9]+)/);
            name = m ? ("Chap " + m[1]) : link;
        }
        items.push({
            name: name,
            url: link,
            host: BASE_URL
        });
    });
    if (items.length === 0) {
        return Response.error("Không có danh sách chap (mục này có thể là sách PDF/audio, không đọc được trên vBook)");
    }
    let data = [];
    for (let i = items.length - 1; i >= 0; i--) {
        data.push(items[i]);
    }
    return Response.success(data);
}
