load('config.js');
function execute() {
    let response = httpGet(BASE_URL + "/truyen-tranh/");
    if (response.ok) {
        let doc = response.html();
        let genres = [];
        let seen = {};
        genres.push({
            title: "Tất cả",
            input: BASE_URL + "/truyen-tranh/",
            script: "gen.js"
        });
        doc.select("#sub-truyen-tranh a").forEach(function (e) {
            let href = e.attr("href");
            if (!href || href.indexOf("/truyen-tranh/") < 0) return;
            let link = absUrl(href);
            if (seen[link]) return;
            seen[link] = true;
            genres.push({
                title: e.text(),
                input: link,
                script: "gen.js"
            });
        });
        if (genres.length > 1) {
            return Response.success(genres);
        }
    }
    return Response.success([
        { title: "Manga", input: BASE_URL + "/truyen-tranh/manga/", script: "gen.js" },
        { title: "Manhua", input: BASE_URL + "/truyen-tranh/manhua/", script: "gen.js" },
        { title: "Manhwa", input: BASE_URL + "/truyen-tranh/manhwa/", script: "gen.js" }
    ]);
}
