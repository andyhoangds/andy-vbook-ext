let BASE_URL = "https://dilib.vn";
try {
    if (CONFIG_URL) {
        let origin = String(CONFIG_URL).match(/^(https?:\/\/[^\/]+)/);
        if (origin) {
            BASE_URL = origin[1];
        }
    }
} catch (error) {
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function normalizeIncomingUrl(url) {
    if (!url) return "";
    return String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
}

function normalizeListUrl(url) {
    url = String(url || "");
    if (!url || /dilib\.vn\/?$/.test(url)) {
        return BASE_URL + "/truyen-tranh/";
    }
    url = normalizeIncomingUrl(url);
    if (url.indexOf(".html") >= 0) return url;
    if (url.charAt(url.length - 1) !== "/") {
        url = url + "/";
    }
    return url;
}

function httpGet(url) {
    return fetch(url, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml"
        }
    });
}

function parseBookList(doc) {
    let data = [];
    let seen = {};
    doc.select(".products .product").forEach(function (e) {
        let a = e.select("h3 a").first();
        if (!a) a = e.select("a.woocommerce-LoopProduct-link").first();
        if (!a) return;
        let href = a.attr("href");
        if (!href || href.indexOf(".html") < 0) return;
        if (href.indexOf("-chap-") >= 0) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        let img = e.select(".block_product_thumbnail img").first();
        let cover = img ? absUrl(img.attr("src")) : "";
        let badge = e.select(".block_product_thumbnail div").first();
        data.push({
            name: a.text(),
            link: link,
            cover: cover,
            description: badge ? badge.text() : "",
            host: BASE_URL
        });
    });
    return data;
}

function nextPageUrl(listUrl, doc) {
    listUrl = String(listUrl || "");
    let m = listUrl.match(/\/page\/(\d+)\/?$/);
    let page = m ? parseInt(m[1], 10) : 1;
    let next = page + 1;
    let probe = doc.select('a[href*="/page/' + next + '"]');
    if (probe.size() === 0) return "";
    return absUrl(probe.first().attr("href"));
}
