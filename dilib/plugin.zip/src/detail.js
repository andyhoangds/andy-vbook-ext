load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL truyện. Dán ví dụ: https://dilib.vn/dao-hai-tac-one-piece-14728.html");
    let response = httpGet(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let nameEl = doc.select("h1").first();
    let coverEl = doc.select("img[src*='/larger/']").first();
    if (!coverEl) coverEl = doc.select("#primary img.border").first();

    let authorEl = doc.select("a[href*='/tac-gia/']").first();
    let detailParts = [];
    doc.select("#primary p.mt10").forEach(function (p) {
        detailParts.push(p.text());
    });

    let genres = [];
    let crumbs = doc.select(".breadcrumbs__item-link");
    if (crumbs.size() > 2) {
        let g = crumbs.get(2);
        genres.push({
            title: g.text(),
            input: absUrl(g.attr("href")),
            script: "gen.js"
        });
    }

    return Response.success({
        name: nameEl ? nameEl.text() : "",
        cover: coverEl ? absUrl(coverEl.attr("src")) : "",
        author: authorEl ? authorEl.text() : "",
        description: doc.select("meta[name=description]").attr("content") || "",
        detail: detailParts.join("<br>"),
        ongoing: true,
        genres: genres,
        host: BASE_URL
    });
}
