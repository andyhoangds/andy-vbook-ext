load('config.js');
function execute(key, page) {
    let q = String(key || "").replace(/^\s+|\s+$/g, "");
    if (!q) return Response.error("Nhập từ khóa tìm kiếm");
    let response = httpGet(BASE_URL + "/search/ajax-search.php?keyword=" + encodeURIComponent(q));
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let data = [];
    let seen = {};
    doc.select("#searchajax a, a[href$='.html']").forEach(function (a) {
        let href = a.attr("href");
        if (!href || href.indexOf(".html") < 0) return;
        if (href.indexOf("-chap-") >= 0) return;
        if (href.indexOf("http") === 0 && href.indexOf("dilib.vn") < 0) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        let img = a.select("img").first();
        let nameEl = a.select("b").first();
        data.push({
            name: nameEl ? nameEl.text() : a.attr("title"),
            link: link,
            cover: img ? absUrl(img.attr("src")) : "",
            description: "",
            host: BASE_URL
        });
    });
    return Response.success(data);
}
