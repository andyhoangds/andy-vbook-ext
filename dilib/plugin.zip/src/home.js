load('config.js');
function execute() {
    return Response.success([
        { title: "Truyện tranh mới", input: BASE_URL + "/truyen-tranh/", script: "gen.js" },
        { title: "Manga", input: BASE_URL + "/truyen-tranh/manga/", script: "gen.js" },
        { title: "Manhua", input: BASE_URL + "/truyen-tranh/manhua/", script: "gen.js" },
        { title: "Manhwa", input: BASE_URL + "/truyen-tranh/manhwa/", script: "gen.js" }
    ]);
}
