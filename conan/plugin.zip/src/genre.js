load('config.js');
function execute() {
    return Response.success([
        { title: "Thám Tử Lừng Danh Conan", input: homeUrl(), script: "gen.js" }
    ]);
}
