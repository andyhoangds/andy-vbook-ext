let BASE_URL = "https://truyentranhconan.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

function absUrl(href) {
    if (!href) return "";
    href = String(href);
    if (href.indexOf("http") === 0) return href;
    if (href.indexOf("//") === 0) return "https:" + href;
    if (href.indexOf("/") === 0) return BASE_URL + href;
    return BASE_URL + "/" + href;
}

function homeUrl() {
    return BASE_URL + "/";
}

function normalizeIncomingUrl(url) {
    if (!url) return homeUrl();
    url = String(url).replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    if (/truyentranhconan\.com\/?$/.test(url) || /truyentranhconan\.com$/.test(url)) {
        return homeUrl();
    }
    return url;
}

function singleBook() {
    return {
        name: "Thám Tử Lừng Danh Conan",
        link: homeUrl(),
        cover: BASE_URL + "/wp-content/uploads/2026/03/CONAN.jpg",
        description: "Gosho Aoyama",
        host: BASE_URL
    };
}

function parseToc(doc) {
    let items = [];
    let seen = {};
    doc.select(".col.post-item a.plain").forEach(function (a) {
        let href = a.attr("href");
        if (!href || href.indexOf("/doc-truyen-conan-chap-") < 0) return;
        let link = absUrl(href);
        if (seen[link]) return;
        seen[link] = true;
        let titleEl = a.select("h5.post-title").first();
        items.push({
            name: titleEl ? titleEl.text() : a.text(),
            url: link,
            host: BASE_URL
        });
    });
    let data = [];
    for (let i = items.length - 1; i >= 0; i--) {
        data.push(items[i]);
    }
    return data;
}
