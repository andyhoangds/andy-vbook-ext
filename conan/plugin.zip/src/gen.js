load('config.js');
function execute(url, page) {
    return Response.success([singleBook()]);
}
