load('config.js');
function execute(url) {
    let response = fetch(homeUrl());
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let data = parseToc(doc);
    if (data.length === 0) {
        return Response.error("Không lấy được danh sách chương");
    }
    return Response.success(data);
}
