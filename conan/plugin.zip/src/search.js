load('config.js');
function execute(key, page) {
    let q = String(key || "").toLowerCase();
    let book = singleBook();
    if (!q || book.name.toLowerCase().indexOf(q) >= 0 || q.indexOf("conan") >= 0 || q.indexOf("thám") >= 0) {
        return Response.success([book]);
    }
    return Response.success([book]);
}
