load('config.js');
function execute(url) {
    url = homeUrl();
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();

    let nameEl = doc.select("h1").first();
    let name = nameEl ? nameEl.text() : "Thám Tử Lừng Danh Conan";

    let coverEl = doc.select("#image_1480853114 img").first();
    if (!coverEl) coverEl = doc.select("img.attachment-large").first();
    let cover = coverEl ? absUrl(coverEl.attr("src")) : (BASE_URL + "/wp-content/uploads/2026/03/CONAN.jpg");

    let info = doc.select(".col-inner ul").first();
    let detailHtml = info ? info.html() : "";
    let author = "Gosho Aoyama";
    let ongoing = true;
    if (detailHtml) {
        if (detailHtml.indexOf("Tác giả") >= 0) {
            let m = detailHtml.match(/Tác giả:<\/strong>\s*([^<]+)/);
            if (m) author = m[1].replace(/^\s+|\s+$/g, "");
        }
        ongoing = detailHtml.indexOf("Đang ra") >= 0;
    }

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: doc.select("meta[name=description]").attr("content") || "",
        detail: detailHtml,
        ongoing: ongoing,
        host: BASE_URL
    });
}
