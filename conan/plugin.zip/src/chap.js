load('config.js');
function execute(url) {
    url = normalizeIncomingUrl(url);
    if (!url) return Response.error("Thiếu URL chương. Dán ví dụ: https://truyentranhconan.com/doc-truyen-conan-chap-1/");
    let response = fetch(url);
    if (!response.ok) return Response.error("HTTP " + response.status);
    let doc = response.html();
    let data = [];
    doc.select("img.chapter-img").forEach(function (e) {
        let img = e.attr("data-src");
        if (!img) img = e.attr("data-lazy-src");
        if (!img) img = e.attr("src");
        if (!img) return;
        if (img.indexOf("data:") === 0) return;
        img = absUrl(img);
        data.push({
            link: img,
            fallback: []
        });
    });
    if (data.length === 0) {
        return Response.error("Không lấy được ảnh chương");
    }
    return Response.success(data);
}
